"""Type system primitives for django-spicedb."""

from .graph import TypeGraph

__all__ = ["TypeGraph"]
