"""Synchronization utilities for django-spicedb."""

from .backfill import backfill_tuples

__all__ = ["backfill_tuples"]
